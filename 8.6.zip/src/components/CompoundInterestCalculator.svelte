<script>
    import { currencyFormatter } from '../utils/currency';
    import { user } from '../store/store';

    let formatter = currencyFormatter($user.bankingData.currency);

    let initialDeposit = 5000;
    let years = 9;
    let interestRate = 10;
    let payment = 200;
    let paymentFrequency = "mensile";
    let interestFrequency = "annuale";

    $: totalPayments = paymentFrequency === "mensile" ? years * 12 : years;
    $: totalPaymentsAmount = totalPayments * payment;
    $: r = interestRate / 100;

    //$: totalInterestsAmount = (payment * (Math.pow(1 + monthlyRate, years * 12) - 1) / monthlyRate) - totalPaymentsAmount;
    $: investmentAmount = payment * Math.pow((1 + r), years);
    $: totalInterestsAmount = investmentAmount;
    $: total = initialDeposit + totalPaymentsAmount + totalInterestsAmount;
</script>

<div class="box">
    <h4 class="title is-4">Calcolo Interessi composti</h4>

    <div class="info">
        <div class="columns has-text-centered is-multiline">
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalPaymentsAmount)}</span><br/>
                <strong>Totale versamenti</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalInterestsAmount)}</span><br/>
                <strong>Totale interessi</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(total)}</span><br/>
                <strong>Capitale finale</strong>
            </div>
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control is-expanded">
            <label for="initialDeposit" class="label">Deposito iniziale (€)</label>
            <input bind:value={initialDeposit} class="input" name="initialDeposit" type="number" placeholder="Deposito iniziale">
        </div>
        <div class="control is-expanded">
            <label for="years" class="label">Durata (anni)</label>
            <input bind:value={years} class="input" name="years" type="number" placeholder="Durata">
        </div>
    </div>
    <div class="field is-grouped">
        <div class="control is-expanded">
            <label for="interestRate" class="label">Tasso di interesse (annuale, %)</label>
            <input bind:value={interestRate} class="input" name="interestRate" type="number" placeholder="Tasso di interesse">
        </div>
        <div class="control is-expanded">
            <label for="payment" class="label">Versamento aggiuntivo (€)</label>
            <input bind:value={payment} class="input" name="payment" type="number" placeholder="Versamento aggiuntivo">
        </div>
    </div>
    <div class="field is-grouped">
        <div class="control is-expanded">
            <label for="paymentFrequency" class="label">Periodicità versamenti</label>
            <div class="select is-fullwidth">
                <select bind:value={paymentFrequency} name="paymentFrequency">
                  <option>Seleziona</option>
                  <option value="mensile">mensile</option>
                  <option value="annuale">annuale</option>
                </select>
            </div>
        </div>
        <div class="control is-expanded">
            <label for="interestFrequency" class="label">Periodicità interessi</label>
            <div class="select is-fullwidth">
                <select bind:value={interestFrequency} name="interestFrequency">
                  <option>Seleziona</option>
                  <option value="mensile">mensile</option>
                  <option value="annuale">annuale</option>
                </select>
            </div>
        </div>
    </div>
</div>

<style>
    .info {
        background-color: #1f2330;
        border-radius: 6px;
        padding: 12px;
        color: #fff;
        margin-bottom: 10px;
    }
    .tag {
        margin-bottom: 10px;
        font-size: 14px;
    }
    strong {
        color: #fff;
    }
</style>