<script>
    import { user } from '../store/store';

    let cardNumberItem = $user.bankingData.creditCardNumber.split(' ');
</script>

<div class="credit-card">
    <div class="card-inner">
        <div class="front">
            <img src="images/map.png" class="map-img" alt="Map">
            <div class="row">
                <img src="images/chip.png" width="60px" alt="Chip">
                <img src="images/visa.png" width="80px" alt="Logo">
            </div>
            <div class="row card-number">
                {#each cardNumberItem as item}
                    <p>{item}</p>
                {/each}
            </div>
            <div class="row card-holder-label">
                <p>Titolare</p>
                <p>Valido fino al</p>
            </div>
            <div class="row card-holder-values">
                <p>{$user.bankingData.holderLabel}</p>
                <p>{$user.bankingData.holderExpirationDate}</p>
            </div>
        </div>
    </div>
</div>

<style>
    .credit-card {
        width: 500px;
        height: 300px;
        color: #fff;
        font-size: 16px;
        border-radius: 12px;
    }
    .card-inner {
        width: 100%;
        height: 100%;
        position: relative;
    }
    .front {
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        left: 0;
        background-image: linear-gradient(45deg, #0045c7, #ff2c7d);
        padding: 5% 7.5%;
        overflow: hidden;
        z-index: 1;
        border-radius: 12px;
    }
    .row {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .map-img {
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        opacity: .3;
        z-index: -1;
    }
    .card-number {
        font-size: 34px;
        margin-top: 15%;
    }
    .card-holder-label {
        font-size: 14px;
        margin-top: 7.5%;
    }
    .card-holder-values {
        font-size: 22px;
    }
</style>