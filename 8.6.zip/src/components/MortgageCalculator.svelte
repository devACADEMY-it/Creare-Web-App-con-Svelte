<script>
    import { currencyFormatter } from '../utils/currency';
    import { user } from '../store/store';

    let formatter = currencyFormatter($user.bankingData.currency);
    let loan = 50000;
    let years = 10;
    let interestRate = 3;

    $: totalPayments = years * 12; // es. 10 * 12
    $: monthlyInterestRate = interestRate / 100 / 12;

    $: monthlyPaymentAmount = 
        (loan * Math.pow(1 + monthlyInterestRate, totalPayments) * monthlyInterestRate) /
        (Math.pow(1 + monthlyInterestRate, totalPayments) - 1);

    $: totalPaid = monthlyPaymentAmount * totalPayments;
    $: totalInterests = totalPaid - loan;
</script>

<div class="box">
    <h4 class="title is-4">Calcolo Mutuo</h4>

    <div class="info">
        <div class="columns has-text-centered is-multiline">
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(monthlyPaymentAmount)}</span><br/>
                <strong>Mensilità</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalPaid)}</span><br/>
                <strong>Totale</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalInterests)}</span><br/>
                <strong>Interessi</strong>
            </div>
        </div>
    </div>

    <div class="field">
        <label for="loan" class="label">Prestito (€)</label>
        <div class="control">
            <input
                bind:value={loan}
                class="input"
                name="loan"
                type="number"
                min="5000"
                max="300000"
                step="500"
                placeholder="Totale prestito"
            >
        </div>
    </div>
    <div class="field">
        <label for="years" class="label">Durata (anni)</label>
        <div class="control">
            <input
                bind:value={years}
                class="input"
                name="years"
                type="number"
                min="1"
                max="30"
                step="1"
                placeholder="Durata"
            >
        </div>
    </div>
    <div class="field">
        <label for="interestRate" class="label">Tasso di interesse (%)</label>
        <div class="control">
            <input
                bind:value={interestRate}
                class="input"
                name="interestRate"
                type="number"
                min="1"
                max="20"
                step="1"
                placeholder="Tasso di interesse"
            >
        </div>
    </div>
</div>

<style>
    .info {
        background-color: #1f2330;
        border-radius: 6px;
        padding: 12px;
        color: #fff;
        margin-bottom: 10px;
    }
    .tag {
        margin-bottom: 10px;
        font-size: 14px;
    }
    strong {
        color: #fff;
    }
</style>