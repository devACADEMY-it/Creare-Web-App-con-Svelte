<script>
	import { beforeUpdate, afterUpdate } from 'svelte';
	let comments = [
		{
			author: 'bot',
			text: 'ciao'
		},
		{
			author: 'bot',
			text: 'come stai?'
		},
		{
			author: 'user',
			text: 'tutto bene, tu?'
		},
		{
			author: 'bot',
			text: 'benone'
		},
	];
	let div;
	let autoscroll;

	beforeUpdate(() => {
		autoscroll = div && (div.offsetHeight + div.scrollTop) > (div.scrollHeight - 20);
	});

	afterUpdate(() => {
		if (autoscroll) {
			div.scrollTo(0, div.scrollHeight);
		}
	});

	function handleKeydown(event) {
		if (event.key === 'Enter') {
			const text = event.target.value;
			if (!text) {
				return;
			}

			// Aggiunto il nostro commento
			comments = comments.concat({
				author: 'user',
				text: text
			});

			event.target.value = '';

			setTimeout(() => {
				comments = comments.concat({
					author: 'bot',
					text: 'Ok!'
				});
			}, 500 + Math.random() * 500);
		}
	}
</script>

<div class="container">
	<section class="section">
		<div class="chat">
			<h1 class="title is-2">Chatbot</h1>
		
			<div class="scrollable" bind:this={div}>
				{#each comments as comment}
					<article class={comment.author}>
						<span>{comment.text}</span>
					</article>
				{/each}
			</div>
		
			<input on:keydown={handleKeydown}>
		</div>
	</section>
</div>

<style>
.chat {
	display: flex;
	flex-direction: column;
	height: 400px;
	max-width: 320px;
}

.scrollable {
	flex: 1 1 auto;
	border-top: 1px solid #eee;
	margin: 0 0 0.5em 0;
	overflow-y: auto;
}

article {
	margin: 0.5em 0;
}

.user {
	text-align: right;
}

span {
	padding: 0.5em 1em;
	display: inline-block;
}

.bot span {
	background-color: #eee;
	border-radius: 1em 1em 1em 0;
}

.user span {
	background-color: #0074D9;
	color: white;
	border-radius: 1em 1em 0 1em;
	word-break: break-all;
}
</style>