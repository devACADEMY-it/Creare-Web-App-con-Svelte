<script>
	let age = 30;
	const numbers = [];
</script>

<div class="layout">
	<h2>Direttiva IF</h2>
	
	{#if age < 18}
		<p>Sei minorenne</p>
	{:else if age >= 18}
		<p>Sei maggiorenne</p>
	{/if}

	{#if numbers.length > 0 && numbers.length < 3}
		<p>{numbers}</p>
	{:else if numbers.length > 3}
		<p>Ci sono troppi elementi nell'array</p>	
	{:else if numbers.length === 0}
		<p>Non ci sono elementi nell'array</p>
	{/if}
</div>

<style>
	div.layout {
		width: 80%;
		margin: 0 auto;
	}
</style>