<script>
    export let title;

    function handleClick() {
        console.log('click');
    }
</script>

<div class="box">
    {title}
    <button class="button is-small is-danger is-rounded" on:click={handleClick}>Rimuovi</button>
</div>