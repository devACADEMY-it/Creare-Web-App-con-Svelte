<script>
	import TodoList from './components/TodoList.svelte';

	const tasks = [
		{
			id: 1,
			title: 'Comprare pane e latte',
			category: 'Spesa',
			completed: false,
		},
		{
			id: 2,
			title: 'Registrare video corso Svelte',
			category: 'Lavoro',
			completed: false,
		},
		{
			id: 3,
			title: 'Pulire cucina',
			category: 'Casa',
			completed: false,
		},
		{
			id: 4,
			title: 'Comprare quaderni',
			category: 'Spesa',
			completed: false,
		},
	];
</script>

<div class="container">
	<section class="section">
		<TodoList {tasks} />
	</section>
</div>