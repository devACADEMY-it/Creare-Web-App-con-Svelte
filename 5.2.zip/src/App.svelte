<script>
	const superheroes = [];
	let superhero = {
		fullName: '',
		alias: '',
		superpowers: [],
		weight: 50,
		height: 100,
		hasGroup: false,
	};
</script>

<div class="container">
	<section class="section">
		<h2 class="title is-2">Crea il tuo supereroe</h2>

		<p>{JSON.stringify(superhero, null, 4)}</p>

		<form>
			<div class="field">
				<label for="fullName" class="label">Nome completo</label>
				<div class="control">
					<input class="input" type="text" name="fullName" placeholder="Nome completo" bind:value={superhero.fullName}>
				</div>
			</div>

			<div class="field">
				<label for="alias" class="label">Alias</label>
				<div class="control">
					<input class="input" type="text" name="alias" placeholder="Alias" bind:value={superhero.alias}>
				</div>
			</div>

			<div class="field">
				<label for="superpowers" class="label">Caratteristiche</label>
				<div class="control is-expanded">
					<div class="select is-multiple is-fullwidth">
						<select multiple name="superpowers" bind:value={superhero.superpowers}>
							<option value="intelligence">Intelligenza</option>
							<option value="strength">Forza</option>
							<option value="speed">Velocità</option>
							<option value="durability">Resistenza</option>
							<option value="power">Potenza</option>
							<option value="combat">Combattimento</option>
						</select>
					</div>
				</div>
			</div>

			<div class="field is-grouped">
				<p class="control is-expanded">
					<label class="label" for="height">Altezza</label>
					<input class="input" type="number" min="100" max="300" step="1" name="height" placeholder="Altezza" bind:value={superhero.height}>
				</p>

				<p class="control is-expanded">
					<label class="label" for="weight">Peso</label>
					<input class="input" type="number" min="50" max="300" step="0.5" name="weight" placeholder="Peso" bind:value={superhero.weight}>
				</p>
			</div>

			<div class="field">
				<div class="control">
					<label for="hasGroup" class="checkbox">
						<input type="checkbox" name="hasGroup" bind:checked={superhero.hasGroup}>
						Fa parte di un gruppo?
					</label>
				</div>
			</div>

			<div class="buttons">
				<button class="button is-danger is-outlined">Reset</button>
				<button class="button is-primary">Crea</button>
			</div>
		</form>
	</section>
</div>