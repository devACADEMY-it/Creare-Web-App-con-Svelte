import { writable } from 'svelte/store';

function createList() {
    const { subscribe, set, update } = writable(['Comprare il pane', 'Pulire la scrivania']);

    return {
        subscribe,
        addTask: (task) => update(tasks => tasks = [...tasks, task]),
        clearTasks: () => set([]),
    }
}

export const tasks = createList();