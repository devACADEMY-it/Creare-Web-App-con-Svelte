<script>
	import { tasks } from './store/store';
	
	let newTask = "";

	function handleClick() {
		tasks.addTask(newTask);
		newTask = "";
	}
</script>

<div class="container">
	<section class="section">
		<input type="text" bind:value={newTask} />
		<button class="button is-primary" on:click={handleClick}>Add task</button>
		<button class="button is-danger" on:click={tasks.clearTasks}>Reset</button>
		<ul>
			{#each $tasks as task}
				<li>{task}</li>
			{/each}
		</ul>
	</section>
</div>

<style>

</style>