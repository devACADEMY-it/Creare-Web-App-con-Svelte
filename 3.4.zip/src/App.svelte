<script>
	import { fade } from 'svelte/transition';

	let randomNumber;

	getRandom();

	function getRandom() {
		randomNumber = Math.floor(Math.random()*10);
	}
</script>

<div class="layout">
	<h2>Direttiva KEY</h2>

	<button on:click={getRandom}>get random</button>
	
	{#key randomNumber}
		<div transition:fade>{randomNumber}</div>
	{/key}
</div>

<style>
	:global(*) {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}

	:global(body) {
		font-size: 20px;
	}

	div.layout {
		width: 80%;
		margin: 0 auto;
	}
</style>