<script>
	import { time } from './store/store';

	const formatter = new Intl.DateTimeFormat('it', {
		hour: 'numeric',
		minute: '2-digit',
		second: '2-digit',
	});
</script>

<div class="container">
	<section class="section">
		<h2 class="title is-2">{formatter.format($time)}</h2>
	</section>
</div>

<style>

</style>