import { readable } from 'svelte/store';

// start eseguita sul subscribe
export const time = readable(new Date(), function start(set) {
    const interval = setInterval(() => {
        set(new Date());
    }, 1000)

    // eseguita sull'unsubscribe
    return function stop() {
        clearInterval(interval);
    }
});