<script>
	async function getPokemon() {
		const randomID = Math.floor(Math.random()*150);
		const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${randomID}`);
		const result = await response.json();

		if (result.name) {
			return result;
		} else {
			throw new Error("Errore nel fetch");
		}
	}
	let promise = getPokemon();

	function handleClick() {
		promise = getPokemon();
	}
</script>

<div class="layout">
	<h2>Direttiva AWAIT</h2>
	
	<button on:click={handleClick}>Get random pokemon</button>

	{#await promise}
		<h3>Caricamento pokemon...</h3>
	{:then pokemon}
		<h3>{pokemon.name}</h3>
		<img src={pokemon.sprites.front_default} alt={pokemon.name}>
	{:catch error}
		<h3>Qualcosa è andato storto: {error}</h3>
	{/await}
</div>

<style>
	:global(*) {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}

	:global(body) {
		font-size: 20px;
	}

	div.layout {
		width: 80%;
		margin: 0 auto;
	}
</style>