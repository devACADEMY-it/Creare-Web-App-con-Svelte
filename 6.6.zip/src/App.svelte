<script>
	import Keypad from './components/Keypad.svelte';

	let pin = "";
	$: hiddenPin = pin ? pin.replace(/\d(?!$)/g, '•') : "Inserisci pin: ";

	function handleConfirm() {
		console.log('confirm');
	}
</script>

<div class="container">
	<section class="section">
		<h1 class="title is-2" style="color: { pin ? '#333' : '#ccc' }">{hiddenPin}</h1>
		<Keypad bind:value={pin} on:confirm={handleConfirm} />
	</section>
</div>

<style>

</style>