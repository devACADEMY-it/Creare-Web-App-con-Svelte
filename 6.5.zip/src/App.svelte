<script>
	import { onMount } from 'svelte';

	let canvas;
	let sun = new Image();
	let moon = new Image();
	let earth = new Image();

	onMount(() => {
		const ctx = canvas.getContext('2d');
		sun.src = 'images/sun.png';
		moon.src = 'images/moon.png';
		earth.src = 'images/earth.png';

		let frame = requestAnimationFrame(loop);
		
		function loop() {
			frame = requestAnimationFrame(loop);

			ctx.globalCompositeOperation = 'destination-over';
			ctx.clearRect(0, 0, 300, 300); // clear canvas

			ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
			ctx.strokeStyle = 'rgba(0, 153, 255, 0.4)';
			ctx.save();
			ctx.translate(150, 150);

			// Earth
			const time = new Date();
			ctx.rotate(((2 * Math.PI) / 60) * time.getSeconds() + ((2 * Math.PI) / 60000) * time.getMilliseconds());
			ctx.translate(105, 0);
			ctx.fillRect(0, -12, 40, 24); // Shadow
			ctx.drawImage(earth, -12, -12);

			// Moon
			ctx.save();
			ctx.rotate(((2 * Math.PI) / 6) * time.getSeconds() + ((2 * Math.PI) / 6000) * time.getMilliseconds());
			ctx.translate(0, 28.5);
			ctx.drawImage(moon, -3.5, -3.5);
			ctx.restore();

			ctx.restore();

			ctx.beginPath();
			ctx.arc(150, 150, 105, 0, Math.PI * 2, false); // Earth orbit
			ctx.stroke();

			ctx.drawImage(sun, 0, 0, 300, 300);
		}

		return () => {
			cancelAnimationFrame(frame);
		};
	});
</script>

<div class="container">
	<section class="section">
		<canvas
			width="300"
			height="300"
			bind:this={canvas}
		></canvas>
	</section>
</div>

<style>

</style>