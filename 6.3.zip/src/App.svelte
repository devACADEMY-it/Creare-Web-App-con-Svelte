<script>
	import { onMount } from 'svelte';
	let photos = [];

	onMount(async () => {
		const result = await fetch('https://jsonplaceholder.typicode.com/photos?_limit=20');
		photos = await result.json();
	});
</script>

<div class="container">
	<section class="section">
		<div class="columns is-multiline">
			{#each photos as photo}
				<div class="column is-2">
					<img src={photo.thumbnailUrl} alt={photo.title}>
				</div>
			{:else}
				<h2 class="title is-2">Caricamento...</h2>
			{/each}
		</div>
	</section>
</div>