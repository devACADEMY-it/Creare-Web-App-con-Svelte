<script>
    import { currencyFormatter } from '../utils/currency';
    import { user } from '../store/store';

    /*
    Compound interest for principal: P(1+r/n)(nt)
    Future value of a series: PMT × {[(1 + r/n)(nt) - 1] / (r/n)} × (1+r/n)
    Total = [ Compound interest for principal ] + [ Future value of a series ]

    A = the future value of the investment/loan, including interest
    P = the principal investment amount (the initial deposit or loan amount)
    PMT = the monthly payment
    r = the annual interest rate (decimal)
    n = the number of times that interest is compounded per unit t
    t = the time (months, years, etc) the money is invested or borrowed for
    */

    let formatter = currencyFormatter($user.bankingData.currency);

    let initialDeposit = 5000;
    let month = 12;
    let years = 9;
    let interestRate = 10;
    let payment = 200;

    $: totalPaymentsAmount = years * month * payment;
    $: r = interestRate / 100;
    $: compoundPrincipal = initialDeposit * Math.pow(1 + r/month, years * month);
    $: compoundFutureValue = payment * [(Math.pow(1 + r/month, years * month) - 1) / (r/month)] * (1 + r/month);
    $: totalWithInterest = compoundPrincipal + compoundFutureValue;
    $: totalInterestAmount = totalWithInterest - totalPaymentsAmount;
</script>

<div class="box">
    <h4 class="title is-4">Calcolo Interessi composti</h4>
    <h5 class="subtitle is-5">Periodicità versamenti e interessi: mensile</h5>

    <div class="info">
        <div class="columns has-text-centered is-multiline">
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalPaymentsAmount)}</span><br/>
                <strong>Totale versamenti</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalInterestAmount)}</span><br/>
                <strong>Interessi maturati</strong>
            </div>
            <div class="column is-4">
                <span class="tag is-medium is-info is-light">{formatter.format(totalWithInterest)}</span><br/>
                <strong>Capitale finale</strong>
            </div>
        </div>
    </div>

    <div class="field is-grouped">
        <div class="control is-expanded">
            <label for="initialDeposit" class="label">Deposito iniziale (€)</label>
            <input bind:value={initialDeposit} class="input" name="initialDeposit" type="number" placeholder="Deposito iniziale">
        </div>
        <div class="control is-expanded">
            <label for="years" class="label">Durata (anni)</label>
            <input bind:value={years} class="input" name="years" type="number" placeholder="Durata">
        </div>
    </div>
    <div class="field is-grouped">
        <div class="control is-expanded">
            <label for="interestRate" class="label">Tasso di interesse (annuale, %)</label>
            <input bind:value={interestRate} class="input" name="interestRate" type="number" placeholder="Tasso di interesse">
        </div>
        <div class="control is-expanded">
            <label for="payment" class="label">Versamento aggiuntivo (€)</label>
            <input bind:value={payment} class="input" name="payment" type="number" placeholder="Versamento aggiuntivo">
        </div>
    </div>
</div>

<style>
    .info {
        background-color: #1f2330;
        border-radius: 6px;
        padding: 12px;
        color: #fff;
        margin-bottom: 10px;
    }
    .tag {
        margin-bottom: 10px;
        font-size: 14px;
    }
    strong {
        color: #fff;
    }
</style>