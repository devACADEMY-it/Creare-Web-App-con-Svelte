export const currencyFormatter = function(currency) {
    return new Intl.NumberFormat('it', {
        style: 'currency',
        currency: currency
    });
}