<script>
	import BankAccount from "./components/BankAccount.svelte";
	import CompoundInterestCalculator from "./components/CompoundInterestCalculator.svelte";
	import MortgageCalculator from "./components/MortgageCalculator.svelte";
</script>

<div class="container">
	<section class="section">
		<div class="columns">
			<div class="column is-12">
				<BankAccount />
			</div>
		</div>
		<div class="columns">
			<div class="column is-6">
				<MortgageCalculator />
			</div>
			<div class="column is-6">
				<CompoundInterestCalculator />
			</div>
		</div>
	</section>
</div>

<style>
	:global(body) {
		background-color: #1f2330;
		width: 100%;
    	height: 100vh;
	}
</style>