<script>
	import Widget from './components/Widget.svelte';
</script>

<div class="container">
	<section class="section">
		<Widget>
			<h4 class="title is-4" slot="header">Mio testo</h4>
			<div slot="body">
				<img src="https://upload.wikimedia.org/wikipedia/it/thumb/9/95/Charizard.png/1200px-Charizard.png" alt="">
				<p>Charizard</p>
			</div>
		</Widget>
	</section>
</div>