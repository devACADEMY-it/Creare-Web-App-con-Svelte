<script>

</script>

<article class="message">
    <div class="message-header">
        <slot name="header"></slot>
    </div>
    <div class="message-body">
        <slot name="body"></slot>
    </div>
</article>