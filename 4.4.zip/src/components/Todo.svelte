<script>
    import { createEventDispatcher } from 'svelte';
    export let id;
    export let title;
    export let category;
    export let completed;

    const dispatch = createEventDispatcher();

    function handleClick() {
        dispatch('removeTodo', {
            id: id
        })
    }
</script>

<div class="box">
    <div class="level">
        <div class="level-left">
            <span class="tag">
                {category}
            </span>
            <p class="{completed ? 'completed' : ''}"><strong>{title}</strong></p>
        </div>
        <div class="level-right">
            <button class="button is-small is-danger is-rounded" on:click={handleClick}>Rimuovi</button>
        </div>
    </div>
</div>

<style>
.completed {
    text-decoration: line-through;
}
</style>