<script>
    import Todo from './Todo.svelte';

    export let tasks;
</script>

<h2 class="title is-2">TodoList</h2>

{#each tasks as task}
    <Todo
        {...task}
        on:removeTodo
    />
{/each}

