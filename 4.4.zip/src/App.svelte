<script>
	import TodoList from './components/TodoList.svelte';

	let tasks = [
		{
			id: 1,
			title: 'Comprare pane e latte',
			category: 'Spesa',
			completed: true,
		},
		{
			id: 2,
			title: 'Registrare video corso Svelte',
			category: 'Lavoro',
			completed: false,
		},
		{
			id: 3,
			title: 'Pulire cucina',
			category: 'Casa',
			completed: false,
		},
		{
			id: 4,
			title: 'Comprare quaderni',
			category: 'Spesa',
			completed: false,
		},
	];

	function handleRemoveTodo(event) {
		// rimuovere l'elemento da tasks
		const findIndex = tasks.findIndex(task => task.id === event.detail.id);
		tasks.splice(findIndex, 1);
		tasks = tasks;
	}
</script>

<div class="container">
	<section class="section">
		<TodoList {tasks} on:removeTodo={handleRemoveTodo} />
	</section>
</div>