<script>
    import { count } from '../store/count';

    function increment() {
        count.update(value => value + 1);
    }
</script>

<button on:click={increment}>+</button>