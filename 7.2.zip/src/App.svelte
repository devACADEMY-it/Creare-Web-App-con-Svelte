<script>
	import { onDestroy } from 'svelte';
	import { count } from './store/count';
	import Incrementer from './components/Incrementer.svelte';
	import Decrementer from './components/Decrementer.svelte';

	/*
	let count_value;
	
	const unsubscribe = count.subscribe(value => {
		count_value = value;
	});

	onDestroy(unsubscribe);
	*/

	$: doubled = $count * 2;
</script>

<div class="container">
	<section class="section">
		<h1 class="title is-2">Value: {$count}</h1>
		<h1 class="title is-2">Doubled: {doubled}</h1>

		<Incrementer />
		<Decrementer />
	</section>
</div>

<style>

</style>