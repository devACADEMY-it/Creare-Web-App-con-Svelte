<script>
	let disabled = true;
	let imgAttrs = {
		src: null,
		alt: null,
	};
	let path = "titolo-articolo";

	function handleImgTag() {
		imgAttrs.src = "https://upload.wikimedia.org/wikipedia/commons/e/ec/Costanzobau_%28cropped%29.jpg";
		imgAttrs.alt = "Maurizio Costanzo";
	}
</script>

<div class="layout">
	<h2>Attributi dinamici</h2>
	<a href="/posts/{path}">Vai al div</a>

	<img {...imgAttrs} />
	<button {disabled}>Click me!</button>
	<button on:click={() => disabled = !disabled}>Toggle disabled</button>
	<button on:click={() => handleImgTag()}>Update image</button>

	<div id="mio-id">
		<p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa eum fugiat inventore sapiente quis magnam eius, consequatur corrupti mollitia sunt dignissimos ipsa nemo labore cumque est ea, beatae nulla. Nobis aliquid vero quidem perferendis incidunt voluptatem error ad amet minima, nemo cum eum facilis veritatis aspernatur est debitis repudiandae optio facere vitae, minus reiciendis! Doloribus sequi laborum nobis explicabo accusamus aliquid at, eum, praesentium earum tempora cupiditate cum modi necessitatibus architecto iste quia quos sunt provident! Similique in hic sequi, repellendus quia id libero enim aliquam molestiae, quam assumenda. Quisquam, in pariatur molestiae voluptas laborum sit quae praesentium blanditiis quis sed esse adipisci reiciendis libero dolor similique corporis unde molestias ab? Aliquam, placeat asperiores adipisci deleniti dicta, tempora in ex fugiat sit omnis cupiditate laudantium minus corporis labore nisi mollitia sint accusantium fuga expedita nemo. Totam ipsam similique eius obcaecati laudantium ipsa possimus. Eaque laborum expedita molestiae dolorem veritatis tempore id porro doloribus corrupti accusantium, eius soluta, quibusdam praesentium ex nobis alias! Iure laborum non aperiam reiciendis ad deserunt reprehenderit, illum vel sed eius perferendis ullam corrupti doloremque placeat provident molestiae totam quidem cumque recusandae quod facere impedit cupiditate labore? Laborum officiis non, fugiat unde ipsa at culpa dolorum nulla.</p>
	</div>
</div>

<style>
	div.layout {
		width: 80%;
		margin: 0 auto;
	}
</style>