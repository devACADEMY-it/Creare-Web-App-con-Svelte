import { writable } from 'svelte/store';

function createUser() {
    const { subscribe } = writable({
        name: 'Adriano',
        surname: 'Grimaldi',
        age: 30,
        bankingData: {
            iban: 'IT08Y0300203280793557134439',
            creditCardNumber: '5555 3333 1111 2222',
            balance: 85000,
            currency: 'EUR',
            holderExpirationDate: '10/25',
            holderLabel: 'Adriano Grimaldi'
        }
    });

    return {
        subscribe
    };
}

export const user = createUser();