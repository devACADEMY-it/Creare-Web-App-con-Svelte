<script>
    import { user } from '../store/store';
    import CreditCard from './CreditCard.svelte';
</script>

<h2 class="title is-2 has-text-white">Bentornato, {$user.name}</h2>
<CreditCard />