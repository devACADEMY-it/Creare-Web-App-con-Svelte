<script>
	import { setContext } from 'svelte';
	import ShowUsers from './components/ShowUsers.svelte';

	const users = [
		{
			username: 'carmhack',
			fullName: 'Adriano Grimaldi',
		},
		{
			username: 'zeb89',
			fullName: 'Zaccaria De Giovanni',
		},
		{
			username: 'piero91',
			fullName: 'Piero Roccia',
		},
	]

	setContext('showGrid', true);
</script>

<div class="container">
	<section class="section">
		<ShowUsers {users} />
	</section>
</div>