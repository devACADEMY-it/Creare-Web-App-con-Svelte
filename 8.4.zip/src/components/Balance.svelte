<script>
    import { user } from '../store/store';
    import { currencyFormatter } from '../utils/currency';

    let formatter = currencyFormatter($user.bankingData.currency);
    let balance = formatter.format($user.bankingData.balance);

    $: fullName = `${$user.surname} ${$user.name}`;
</script>

<div class="box">
    <h2 class="title is-2">La tua situazione</h2>
    <h4 class="subtitle is-4">{fullName}, nato il {$user.birthDate}</h4>

    <span class="tag is-large is-info is-light">{$user.bankingData.iban}</span><br/><br/>
    <span class="tag is-large is-success is-light">Saldo: {balance}</span>
</div>

<style>
    .box {
        height: 300px;
    }
</style>