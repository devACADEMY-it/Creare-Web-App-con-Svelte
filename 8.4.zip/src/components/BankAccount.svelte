<script>
    import CreditCard from './CreditCard.svelte';
    import Balance from './Balance.svelte';
    import { user } from '../store/store';
</script>

<h2 class="title is-2 has-text-white">Bentornato, {$user.name}</h2>
<div class="columns">
    <div class="column">
        <CreditCard />
    </div>
    <div class="column">
        <Balance />
    </div>
</div>
