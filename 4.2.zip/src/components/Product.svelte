<script>
    import { createEventDispatcher } from 'svelte';

    const dispatch = createEventDispatcher();

    export let imgPath = 'https://upload.wikimedia.org/wikipedia/commons/f/fc/No_picture_available.png';
    export let name;
    export let price;
    
    function handleClick() {
        // dispatch di un evento
        dispatch('addToCart', {
            name: name
        });
    }
</script>

<div class="product">
    <img src={imgPath} alt={name}>
    <h2>{name}</h2>
    <span>{price} €</span>
    <button on:click={handleClick}>Aggiungi al carrello</button>
</div>

<style>
.product {
    width: 300px;
    text-align: center;
}
img {
    width: 250px;
    height: auto;
}
h2 {
    margin-bottom: 10px;
}
span {
    background-color: #000;
    color: #fff;
    padding: 6px 12px;
    border-radius: 6px;
}
</style>