<script>
	import Product from './components/Product.svelte'

	const products = [
		{
			imgPath: 'https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-13-pro-max-graphite-select?wid=940&hei=1112&fmt=png-alpha&.v=1631652956000',
			name: 'Iphone 13',
			price: 1300
		},
		{
			name: 'Samsung S21',
			price: 800
		}
	];

	const cart = {
		products: [],
		total: 0
	};

	function handleAddToCart(event) {
		const findItem = products.find(product => product.name === event.detail.name);
		if (findItem) {
			cart.products.push(findItem);
			cart.total += findItem.price;
		}
	}
</script>

<div class="layout">
	{#each products as product}
		<Product
			imgPath={product.imgPath}
			name={product.name}
			price={product.price}
			on:addToCart={handleAddToCart}
		/>
	{/each}

	<h3>Totale carrello: {cart.total} - Elementi aggiunti: {cart.products.length}</h3>
</div>

<style>
	:global(*) {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}

	:global(body) {
		font-size: 20px;
	}

	div.layout {
		width: 80%;
		margin: 0 auto;
	}
</style>