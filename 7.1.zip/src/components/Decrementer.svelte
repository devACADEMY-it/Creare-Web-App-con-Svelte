<script>
    import { count } from '../store/count';

    function decrement() {
        count.update(value => value - 1);
    }
</script>

<button on:click={decrement}>-</button>